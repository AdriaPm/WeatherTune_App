// ignore_for_file: non_constant_identifier_names

String API_KEY = "9521fffe8c47941cbe4fd2102ef11043";

bool API_Key_Active = true;
