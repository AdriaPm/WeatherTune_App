class LocationData {
  final String location;
  final int weatherCondition;
  final String temperature;

  LocationData(this.location, this.weatherCondition, this.temperature);
}
